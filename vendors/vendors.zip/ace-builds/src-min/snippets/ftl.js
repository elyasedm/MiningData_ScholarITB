define("ace/snippets/ftl",["require","exports","module"],function(e,t,n){"use strict";t.snippetText="",t.scope="ftl"});
                (function() {
                    window.require(["ace/snippets/ftl"], function(m) {
                        if (typeof module == "object" && typeof exports == "object" && module) {
                            module.exports = m;
                        }
                    });
                })();
            